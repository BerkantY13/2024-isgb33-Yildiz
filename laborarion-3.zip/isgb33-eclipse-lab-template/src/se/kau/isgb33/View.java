package se.kau.isgb33;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class View extends JFrame {
    private JTextArea textArea; // Textområdet där resultatet visas
    private JTextField textField; // Textrutan där användaren kan skriva in
    private JButton searchButton; // Knappen för sökningen 

    public View() {
        setTitle("Filmförslag.nu"); // Sätter fönstertiteln
        setSize(400, 500); // Anger storleken på fönstret
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Stänger applikationen när fönstret stängs
        setLayout(null); // Stänger av layout-hanteraren för manuell positionering

        //Skapar textområdet och placerar den
        textArea = new JTextArea();
        textArea.setBounds(10, 10, 365, 400);
        textArea.setLineWrap(true); // Gör så att texten radbryts
        textArea.setEditable(false); // Gör textområdet skrivskyddat

        // Skapar och placerar textrutan
        textField = new JTextField();
        textField.setBounds(10, 415, 260, 40);

        // Skapar knappen och placerar den 
        searchButton = new JButton("Sök!");
        searchButton.setBounds(275, 415, 100, 40);

        // Lägger till komponenterna i fönstret
        add(textArea);
        add(textField);
        add(searchButton);
        setVisible(true); // Gör fönstret synligt
    }

    // Laddar texten som användaren har skrivit in
    public String getCategoryInput() {
        return textField.getText();
    }

    // texten som visas i textområdet
    public void setResultText(String result) {
        textArea.setText(result);
    }

    // Lägger till lyssnare för knappen
    public void addSearchListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }
}
