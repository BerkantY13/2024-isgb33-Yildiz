package se.kau.isgb33;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller {
    private Model model; // Referens till modellen (databaslogik)
    private View view; // Referens till vyn (GUI)

    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;

        // Lägger till en lyssnare till sökknappen
        view.addSearchListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Hämtar genren från användarens inmatning
                String genre = view.getCategoryInput();
                // Hämtar filmer baserat på genren från modellen
                String result = model.getMoviesByGenre(genre);
                // Visar resultatet i vyn
                view.setResultText(result);
            }
        });
    }
}
