package se.kau.isgb33;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;

import org.bson.Document;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;

public class Model {
    private MongoCollection<Document> collection;

    public Model() {
        try (InputStream input = new FileInputStream("connection.properties")) {
            // Läser in databasanslutningsinställningar från en fil
            Properties prop = new Properties();
            prop.load(input);

            String connString = prop.getProperty("db.connection_string");
            ConnectionString connectionString = new ConnectionString(connString);
            // Skapar inställningarna för att ansluta till MongoDB
            MongoClientSettings settings = MongoClientSettings.builder().applyConnectionString(connectionString).build();
            MongoClient mongoClient = MongoClients.create(settings);

            // Ansluter till databasen med namnet som anges i properties-filen
            MongoDatabase database = mongoClient.getDatabase(prop.getProperty("db.name"));
            // Hämtar kollektionen "movies" från databasen
            this.collection = database.getCollection("movies");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getMoviesByGenre(String genre) {
        // Skapar en sträng för att lagra resultatet
        StringBuilder result = new StringBuilder();

        // Utför en databasfråga för att söka efter filmer utifrån deras genre
        MongoCursor<Document> cursor = collection.aggregate(Arrays.asList(
            Aggregates.match(Filters.in("genres", genre)), // Filtrerar på genren i genres-arrayen
            Aggregates.project(Projections.fields(Projections.include("title", "year"))), // Hämtar bara "title" och "year"
            Aggregates.sort(Sorts.descending("title")), // Sorterar i omvänd bokstavsordning 
            Aggregates.limit(10) // Begränsar resultatet till max 10 dokument
        )).iterator();

        if (!cursor.hasNext()) {
            // Om inte filmerna hittas, visa ett felmeddelande
            return "Ingen film matchade kategorin";
        }

        while (cursor.hasNext()) {
            // Loopar genom resultaten och bygger upp resultatsträngen
            Document doc = cursor.next();
            result.append(doc.getString("title")).append(", ").append(doc.get("year")).append("\n");
        }
        return result.toString(); // Resultatet retuneras som en stränf
    }
}
