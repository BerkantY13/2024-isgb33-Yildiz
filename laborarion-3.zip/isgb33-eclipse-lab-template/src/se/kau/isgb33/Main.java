package se.kau.isgb33;

public class Main {
    public static void main(String[] args) {
    	// Skapar Model, View och Controller
        Model model = new Model();
        View view = new View();
        new Controller(model, view); // Kopplar ihop Model och View med Controller
    }
}